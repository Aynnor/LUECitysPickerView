//
//  UIAddressPickerView.m
//  AddressPickerView
//
//  Created by benlue1992 on 2018/6/5.
//  Copyright © 2018年 benlue1992. All rights reserved.
//

#import "UIAddressPickerView.h"

#define IsiPhoneX (CGSizeEqualToSize(CGSizeMake(375.f, 812.f), [UIScreen mainScreen].bounds.size) || CGSizeEqualToSize(CGSizeMake(812.f, 375.f), [UIScreen mainScreen].bounds.size))

@interface UIAddressPickerView ()<UIPickerViewDelegate,UIPickerViewDataSource>

@property (nonatomic, weak) UIPickerView *addressPickerView;

@property (nonatomic, strong) NSArray *provinces;//省份列表province
@property (nonatomic, strong) NSArray *citys;//省份下有多少个市city
@property (nonatomic, strong) NSArray *areas;//市下有多少个区area

@property (nonatomic, copy) NSString *provinceStr;
@property (nonatomic, copy) NSString *cityStr;
@property (nonatomic, copy) NSString *areaStr;


@property (nonatomic, weak) UIView *topOperationView;///<顶部titleView
@property (nonatomic, weak) UIButton *cancelButton;///<取消按钮
@property (nonatomic, weak) UIButton *sureButton;///<确定按钮
@property (nonatomic, weak) UILabel *addressLabel;///<显示选中的省市区label



@end
@implementation UIAddressPickerView
{
    CGFloat _PickerButtonWidth;//默认80
    CGFloat _PickerOperationViewHeight;//默认44
    CGFloat _PickerBottomMarginViewHeight;//iphonex 34 else 0
}


-(void)setProvinceStr:(NSString *)provinceStr {
    _provinceStr = provinceStr;
    _addressLabel.text = [NSString stringWithFormat:@"已选: %@ %@ %@", provinceStr , self.cityStr, self.areaStr];
}
-(void)setCityStr:(NSString *)cityStr {
    _cityStr = cityStr;
    _addressLabel.text = [NSString stringWithFormat:@"已选: %@ %@ %@", self.provinceStr , cityStr, self.areaStr];
}
-(void)setAreaStr:(NSString *)areaStr {
    _areaStr = areaStr;
    _addressLabel.text = [NSString stringWithFormat:@"已选: %@ %@ %@", self.provinceStr , self.cityStr, _areaStr];
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        _PickerButtonWidth = 80;
        _PickerOperationViewHeight = 44;
        _PickerBottomMarginViewHeight = (IsiPhoneX ? 34 : 0);
        self.backgroundColor = [UIColor groupTableViewBackgroundColor];
        [self createUI];
    }
    return self;
}

#pragma mark - createUI
- (void)createUI {
    NSError *err = nil;
    //读取json
    NSString *path = [[NSBundle mainBundle] pathForResource:@"ChinaCityList.json" ofType:nil];
    NSData *date = [NSData dataWithContentsOfFile:path];
    _provinces = [NSJSONSerialization JSONObjectWithData:date options:0 error:&err];
    
    if (err) {
        NSLog(@"%@",err);
    }
    
    //创建顶部操作栏
    [self createOperationView];
    
    //创建底部间隔
    UIView *bottomMarginView = [[UIView alloc] initWithFrame:CGRectMake(0, self.bounds.size.height - _PickerBottomMarginViewHeight, self.bounds.size.width, self.bounds.size.height)];
    _bottomMarginView = bottomMarginView;
    bottomMarginView.backgroundColor = [UIColor groupTableViewBackgroundColor];
    [self addSubview:bottomMarginView];
    
    //创建picker
    UIPickerView *addressPickerView = [[UIPickerView alloc] initWithFrame:CGRectMake(0, _PickerOperationViewHeight, self.bounds.size.width, self.bounds.size.height - _PickerOperationViewHeight - _PickerBottomMarginViewHeight)];
    _addressPickerView = addressPickerView;
    addressPickerView.delegate = self;
    addressPickerView.dataSource = self;
    
    [self addSubview:addressPickerView];
    
    
    //读取之前的选择
    [self recordUserSelectedLocationWithAddress:NO];
}

#pragma mark - 创建顶部横条
- (void)createOperationView {
    
    //顶部
    UIView *topOperationView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.bounds.size.width, _PickerOperationViewHeight)];
    _topOperationView = topOperationView;
    topOperationView.backgroundColor = [UIColor whiteColor];
    
    [self addSubview:topOperationView];
    
    
    //取消按钮
    UIButton *cancelButton = [UIButton buttonWithType:UIButtonTypeSystem];
    _cancelButton = cancelButton;
    cancelButton.titleLabel.font = [UIFont systemFontOfSize:16];
    [cancelButton setTitle:@"取消" forState:UIControlStateNormal];
    
    [topOperationView addSubview:cancelButton];
    cancelButton.frame = CGRectMake(0, 0, _PickerButtonWidth, _PickerOperationViewHeight);
    
    //确定按钮
    UIButton *sureButton = [UIButton buttonWithType:UIButtonTypeSystem];
    _sureButton = sureButton;
    sureButton.titleLabel.font = [UIFont systemFontOfSize:16];
    [sureButton setTitle:@"确定" forState:UIControlStateNormal];
    
    [topOperationView addSubview:sureButton];
    sureButton.frame = CGRectMake(self.bounds.size.width - _PickerButtonWidth, 0, _PickerButtonWidth, _PickerOperationViewHeight);
    
    
    //显示选中的省市区label
    UILabel *addressLabel = [UILabel new];
    _addressLabel = addressLabel;
    addressLabel.font = [UIFont systemFontOfSize:15];
    addressLabel.textColor = [UIColor darkTextColor];
    addressLabel.textAlignment = NSTextAlignmentCenter;
    addressLabel.adjustsFontSizeToFitWidth = YES;
    
    [topOperationView addSubview:addressLabel];
    addressLabel.frame = CGRectMake(_PickerButtonWidth, 0, self.bounds.size.width - 2*_PickerButtonWidth, _PickerOperationViewHeight);
    
    //顶部加个分割线
    UIView *line = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.bounds.size.width, 0.5f)];
    line.backgroundColor = [UIColor groupTableViewBackgroundColor];
    [topOperationView addSubview:line];
    
    cancelButton.tag = 1;
    sureButton.tag = 0;
    [cancelButton addTarget:self action:@selector(clickCancelOrSureButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    [sureButton addTarget:self action:@selector(clickCancelOrSureButtonAction:) forControlEvents:UIControlEventTouchUpInside];
}



#pragma mark - pickerView数据源
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 3;//3竖列表
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    
    switch (component) {
        case 0:{
            return self.provinces.count;
        }
            break;
        case 1:{
            return self.citys.count;
        }
            break;
        default:{//2
            return self.areas.count;
        }
            break;
    }
}

#pragma mark - pickerView代理方法
-(CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component {
    return (self.bounds.size.width - 50)/3;
}
-(CGFloat)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component {
    return 40;
}
-(NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    switch (component) {
        case 0:{
            return self.provinces[row][@"name"];
        }
            break;
        case 1:{
            return self.citys[row][@"name"];
        }
            break;
        default:{//2
            return self.areas[row];
        }
            break;
    }
}

//实现代理方法重定义显示view
-(UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view {
    
    UILabel* pickerLabel = (UILabel*)view;
    if (!pickerLabel){
        pickerLabel = [[UILabel alloc] init];
        pickerLabel.textColor = [UIColor colorWithRed:51.0/255
                                                green:51.0/255
                                                 blue:51.0/255
                                                alpha:1.0];
        pickerLabel.adjustsFontSizeToFitWidth = YES;
        [pickerLabel setTextAlignment:NSTextAlignmentCenter];
        [pickerLabel setFont:[UIFont boldSystemFontOfSize:15]];
    }
    
    pickerLabel.text = [self pickerView:pickerView titleForRow:row forComponent:component];
    return pickerLabel;
}




-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    switch (component) {//多少个省
        case 0:{
            NSDictionary *shenDict = self.provinces[row];
            self.provinceStr = shenDict[@"name"];
            self.citys = shenDict[@"city"];
            [pickerView reloadComponent:1];
            
            [self pickerView:pickerView didSelectRow:0 inComponent:1];
            [pickerView selectRow:0 inComponent:1 animated:NO];
            
            [[NSUserDefaults standardUserDefaults] setValue:@(row) forKey:@"addressProvince"];
        }
            break;
        case 1:{//省下面有多少个市
            NSDictionary *shiDict = self.citys[row];
            self.cityStr = shiDict[@"name"];
            self.areas = shiDict[@"area"];
            [pickerView reloadComponent:2];
            
            [self pickerView:pickerView didSelectRow:0 inComponent:2];
            [pickerView selectRow:0 inComponent:2 animated:NO];
            [[NSUserDefaults standardUserDefaults] setValue:@(row) forKey:@"addressCity"];
        }
            break;
        default:{//市下面有多少个区
            self.areaStr = self.areas[row];
            [[NSUserDefaults standardUserDefaults] setValue:@(row) forKey:@"addressArea"];
        }
            break;
    }
}


#pragma mark - 记录用户选择的地址
-(void)recordUserSelectedLocationWithAddress:(BOOL)isLoad {
    
    if (isLoad == NO) {
        [self pickerView:self.addressPickerView didSelectRow:0 inComponent:0];
        return;//节省性能
    }
    
    NSNumber *pN = [[NSUserDefaults standardUserDefaults] valueForKey:@"addressProvince"];
    NSNumber *cN = [[NSUserDefaults standardUserDefaults] valueForKey:@"addressCity"];
    NSNumber *aN = [[NSUserDefaults standardUserDefaults] valueForKey:@"addressArea"];

    int p = pN.intValue, c = cN.intValue, a = aN.intValue;
    //做容错判断
    if (p >= self.provinces.count) {
        p = 0;
    }

    NSArray *citys = self.provinces[p][@"city"];
    if (c >= citys.count) {
        c = 0;
    }

    NSArray *areas = citys[c][@"area"];
    if (a >= areas.count) {
        a = 0;
    }
    
    if (isLoad) {//主动调一下滚动选中
        [self pickerView:self.addressPickerView didSelectRow:p inComponent:0];
        [self pickerView:self.addressPickerView didSelectRow:c inComponent:1];
        [self pickerView:self.addressPickerView didSelectRow:a inComponent:2];
    }
}

#pragma mark - 取消和确定按钮的点击方法
- (void)clickCancelOrSureButtonAction:(UIButton *)btn {
    if (btn.tag) {//点击的是取消
        [self hiddenPickerView];
    }else{
        //回调选中的地址
        if ([self.delegate respondsToSelector:@selector(didSelectedAddressProvince:city:area:)]) {
            [self.delegate didSelectedAddressProvince:self.provinceStr city:self.cityStr area:self.areaStr];
        }
        [self hiddenPickerView];
    }
}


#pragma mark - 当加入父视图的时候会获取俯视图的Frame, 然后一开始是隐藏起来的
-(void)didMoveToSuperview {
    [super didMoveToSuperview];
    //让picker一开始隐藏
    self.frame = CGRectMake(0, self.superview.bounds.size.height, self.bounds.size.width, self.bounds.size.height);
}

#pragma mark - 以下是show出来的方法
- (void)showPickerView {//注: 若是若是要做打开历史处理则需要在show方法show出来之前跳到指定历史记录
    self.hidden = NO;
    self.userInteractionEnabled = NO;
    
    [UIView animateWithDuration:0.2f animations:^{
        self.frame = CGRectMake(0, self.superview.bounds.size.height - self.bounds.size.height, self.bounds.size.width, self.bounds.size.height);
        [self layoutIfNeeded];
    } completion:^(BOOL finished) {
        if (finished) {
            self.userInteractionEnabled = YES;
            self.currentIsShow = YES;
        }
    }];
}
#pragma mark - 隐藏这个view的方法
-(void)hiddenPickerView {
    self.userInteractionEnabled = NO;
    
    [UIView animateWithDuration:0.2f animations:^{
        self.frame = CGRectMake(0, self.superview.bounds.size.height, self.bounds.size.width, self.bounds.size.height);
        [self layoutIfNeeded];
    } completion:^(BOOL finished) {
        if (finished) {
            self.userInteractionEnabled = YES;
            self.hidden = YES;
            self.currentIsShow = NO;
        }
    }];
}

#pragma mark - 自行设置titleHeight
- (void)setPickerViewHeight:(CGFloat)pickerHeight titleViewHeight:(CGFloat)titleViewHeight; {
    self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, self.frame.size.width, pickerHeight);
    _PickerOperationViewHeight = titleViewHeight;
//    [self layoutIfNeeded];
}

#pragma mark - 重新布局
-(void)layoutSubviews {
    [super layoutSubviews];
    //重新布局
    _topOperationView.frame = CGRectMake(0, 0, self.bounds.size.width, _PickerOperationViewHeight);
    _cancelButton.frame = CGRectMake(0, 0, _PickerButtonWidth, _PickerOperationViewHeight);
    _sureButton.frame = CGRectMake(self.bounds.size.width - _PickerButtonWidth, 0, _PickerButtonWidth, _PickerOperationViewHeight);
    _addressLabel.frame = CGRectMake(_PickerButtonWidth, 0, self.bounds.size.width - 2*_PickerButtonWidth, _PickerOperationViewHeight);
    _addressPickerView.frame = CGRectMake(0, _PickerOperationViewHeight, self.bounds.size.width, self.bounds.size.height - _PickerOperationViewHeight - _PickerBottomMarginViewHeight);
}



@end
