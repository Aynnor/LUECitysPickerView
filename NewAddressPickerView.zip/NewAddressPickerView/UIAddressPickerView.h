//
//  UIAddressPickerView.h
//  AddressPickerView
//
//  Created by benlue1992 on 2018/6/5.
//  Copyright © 2018年 benlue1992. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <YYModel.h>
#import <Masonry.h>


@protocol UIAddressPickerViewDelegate <NSObject>
@optional


/** 回调省市区地址, 地址列表是京东的地址, 可能有些区别 */
-(void)didSelectedAddressProvince:(NSString *)province city:(NSString *)city area:(NSString *)area;



@end
@interface UIAddressPickerView : UIView

@property (nonatomic, weak) id<UIAddressPickerViewDelegate> delegate;///<代理属性

@property (nonatomic, weak) UIView *bottomMarginView;///<底部间隔的View, 适配iPhoneX 34高度, else 0

@property (nonatomic, assign) BOOL currentIsShow;///<当前pickerView是否是展示状态?

@property (nonatomic, assign) BOOL isAutoOpenLast;///<是否show出来的时候自动打开上次记录? Default = No;

/** 自行设置titleHeight */
- (void)setPickerViewHeight:(CGFloat)pickerHeight titleViewHeight:(CGFloat)titleViewHeight;

/** 把这个界面show出来 */
-(void)showPickerView;

/** 把这个界面隐藏出来 */
-(void)hiddenPickerView;

@end
